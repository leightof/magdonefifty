//setup function
function setup() {

	// put setup code here

}

// draw function
function draw() {

	// put draw code here

}