


function preload() {

	//put preload code here

}

function setup() {

	//put setup code here

}


function draw() {

	//put draw code here

}
